package com.app.idnbin.MainScreen.Chat.Model;

public class AllMethods {
    public static  String name = "";
}
